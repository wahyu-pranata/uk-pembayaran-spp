<?php

define('BASE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/pembayaran-spp/public');