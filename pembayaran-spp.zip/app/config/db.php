<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'pembayaran_spp');
define('DB_USER', 'root');
define('DB_PASS', '');