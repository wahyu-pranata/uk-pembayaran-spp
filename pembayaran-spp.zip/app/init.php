<?php

if(!session_id()) session_start();
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/log/log.txt');

$dirs = [
    __DIR__ . '\\core',
    __DIR__ . '\\controller',
    __DIR__ . '\\model',
    __DIR__ . '\\helper',
    __DIR__ . '\\config',
];

foreach($dirs as $dir) {
    foreach(glob("$dir\\*.php") as $file) {
        require_once $file;
    }
}